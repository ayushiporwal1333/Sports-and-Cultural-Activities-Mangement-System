-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 22, 2019 at 08:32 AM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `sports_and_cultural`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`username`, `password`) VALUES
('admin', '123');

-- --------------------------------------------------------

--
-- Table structure for table `cultural`
--

CREATE TABLE IF NOT EXISTS `cultural` (
  `Event` varchar(30) NOT NULL,
  `Venue` varchar(50) NOT NULL,
  `Date` varchar(10) NOT NULL,
  `Time` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cultural`
--

INSERT INTO `cultural` (`Event`, `Venue`, `Date`, `Time`) VALUES
('Dancing', 'Auditorium', '5/5/19', '4pm'),
('Singing', 'Auditorium', '2/5/18', '5pm'),
('Group Dance', 'Auditorium', '5/5/19', '4pm'),
('Group Singing', 'Auditorium', '2/5/18', '5pm');

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE IF NOT EXISTS `registration` (
  `Name` varchar(30) NOT NULL,
  `AUID` varchar(20) NOT NULL,
  `Dep` varchar(30) NOT NULL,
  `Event` varchar(30) NOT NULL,
  `Email` varchar(20) NOT NULL,
  `Mobile` varchar(20) NOT NULL,
  PRIMARY KEY (`AUID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`Name`, `AUID`, `Dep`, `Event`, `Email`, `Mobile`) VALUES
('Vivek', 'AIT18AMCA05', 'MCA', 'Football', 'vivek@gmail.com', '9876543210'),
('Miraj', 'AIT18AMCA04', 'MCA', 'Cricket', 'miraj@gmail.com', '9876543210'),
('Ayushi', 'AIT18AMCA03', 'MCA', 'Singing', 'ayu@gmail.com', '9876543210'),
('Nitya', 'AIT18AMCA02', 'MCA', 'Dancing', 'nitya@gmail.com', '9876543210'),
('Nilu', 'AIT18AMCA01', 'MCA', 'Group Dance', 'nilu@gmail.com', '9876543210');

-- --------------------------------------------------------

--
-- Table structure for table `sports`
--

CREATE TABLE IF NOT EXISTS `sports` (
  `Event` varchar(30) NOT NULL,
  `Venue` varchar(50) NOT NULL,
  `Date` varchar(20) NOT NULL,
  `Time` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sports`
--

INSERT INTO `sports` (`Event`, `Venue`, `Date`, `Time`) VALUES
('Cricket', 'Stadium', '5/5/19', '4pm'),
('Hockey', 'Ground', '6/7/19', '4pm'),
('Football', 'Football Ground', '5/5/19', '3pm');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `AUID` varchar(20) NOT NULL,
  `Name` varchar(30) NOT NULL,
  `Password` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`AUID`, `Name`, `Password`) VALUES
('AIT18AMCA01', 'Amar Raj', 'ait123'),
('AIT18AMCA02', 'Ankit Chhetri', 'ait123'),
('AIT18AMCA03', 'Ayushi Porwal', 'ait123'),
('AIT18AMCA04', 'Md. Miraj Ansari', 'ait123'),
('AIT18AMCA05', 'Nilanjana Chakraborty', 'ait123'),
('AIT18AMCA06', 'Nikita Murgod', 'ait123'),
('AIT18AMCA07', 'Nitya Pandey', 'ait123'),
('AIT18AMCA08', 'Vivek Pandey', 'ait123');
